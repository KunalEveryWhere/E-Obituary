import React from "react";
import './App.css';gi

import TestScreen1 from "./components/TestScreen1.tsx"
import TestScreen2 from "./components/TestScreen2.tsx"



import { Grommet } from 'grommet'

const App = () =>{
    return (
        <Grommet className="App">
                <TestScreen1 />
        </Grommet>
    )
}

export default App
