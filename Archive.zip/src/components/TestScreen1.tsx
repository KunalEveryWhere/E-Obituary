import React from 'react';
import {Heading} from "grommet";

export default function TestScreen1() {
    return (
        <React.Fragment>
            <div className='background1'>
                <div className ="row flex-center flex">
                    <div className='col-12'>
                        <h1 className='title'>Una<span className="emphasis">Eats</span></h1>
                        <h3>Test Screen 1</h3>
                    </div>
                </div>
            </div>
        </React.Fragment>
    )
    }
