import React from 'react';
import {Heading} from "grommet";

export default function TestScreen2() {
    return (
        <React.Fragment>
            <div className ="row flex-center flex">
                <div className='col-12'>
                    <h1 className='title'>Una<span className="emphasis">Eats</span></h1>
                    <h3>Test Screen 2</h3>
                </div>
            </div>
        </React.Fragment>
    )
    }
